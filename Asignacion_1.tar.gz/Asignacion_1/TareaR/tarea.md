---
title: "Asignacion"
author: "Dra. Esther D. Gutierrez"
date: "13 de abril de 2016"
output: html_document
---

## Hola a todos


En esta carpeta encontraran los datos necesarios para realizar la tarea que sera evaluada en la siguiente clase (miercoles 20 de Abril del 2016).

Saludos y mucho exito!!


JLC y EDGM


